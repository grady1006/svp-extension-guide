chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
  chrome.scripting.executeScript({
    target: {tabId: tabs[0].id},
    func: () => {
      const links = [];
      const fileEls = document.querySelectorAll(".coL01.tableinfo-1_2.visible-xs");

      fileEls.forEach(el => {
        const filename = el.getAttribute("data-filename");
        let name = filename;

        const table = el.closest("table");
        let foundName = false;

        // 搜尋 table 中出現在 fileEl 後面的 tableinfo-1_3
        if (table) {
          const cells = Array.from(table.querySelectorAll("td"));
          const fileIndex = cells.indexOf(el);

          for (let i = fileIndex + 1; i < cells.length; i++) {
            if (cells[i].classList.contains("tableinfo-1_3")) {
              name = cells[i].textContent.trim().replace(/\s+/g, " ");
              foundName = true;
              break;
            }
          }
        }

        if (filename) {
          links.push({
            name: name,
            url: "https://tenma-vod.akamaized.net/sgi/" + filename
          });
        }
      });

      return links;
    }
  }, (injectionResults) => {
    const urls = injectionResults[0].result;
    const container = document.getElementById("link-list");
    container.innerHTML = "";
    urls.forEach(({name, url}) => {
      const a = document.createElement("a");
      a.href = url;
      a.textContent = name;
      a.download = name;
      a.target = "_blank";
      container.appendChild(a);
    });
  });
});