setTimeout(() => {
  document.querySelectorAll("[data-filename]").forEach((el) => {
    if (el.classList.contains("coL01") &&
        el.classList.contains("tableinfo-1_2") &&
        el.classList.contains("visible-xs")) {

      const filename = el.getAttribute("data-filename");
      if (filename) {
        const url = `https://tenma-vod.akamaized.net/sgi/${filename}`;
        const link = document.createElement("a");
        link.href = url;
        link.textContent = "下載 SVP 檔案";
        link.download = filename;
        link.style.display = "block";
        link.style.margin = "10px";
        link.style.color = "blue";
        document.body.insertBefore(link, document.body.firstChild);
      }
    }
  });
}, 2000);